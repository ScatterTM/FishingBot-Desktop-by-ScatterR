Fishingbot OBS Startup Setup

1. Open OBS Studio.
2. Open Tools > Scripts.
3. Add fishingbot-autostart.lua from this folder.
4. Follow OBS-SETUP.md if you need to adjust the executable path.

The script starts the installed Fishingbot Desktop when OBS opens.
